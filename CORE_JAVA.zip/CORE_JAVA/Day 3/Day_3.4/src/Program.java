package p1;
class Program
{
    public static void main(String[] args) 
    {
        if(System.out.printf("Hello World") != null )
        {   }
       // System.out.println("Hello World");    
    }
}