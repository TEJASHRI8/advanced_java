package p1;
import java.lang.String;
public class Complex
{
    public String toString()
    {
        return "Complex.toString()";
    }
}