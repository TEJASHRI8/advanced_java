import java.lang.String;
import java.lang.System;
import p1.Complex;
class Program
{
    public static void main( String[] args )
    {
       //p1.Complex c1 = new p1.Complex();
       Complex c1 = new Complex();
       System.out.println(c1.toString()); 
    }
}