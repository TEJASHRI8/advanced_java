package p1;
class Program
{
    public static void main( String[] args )
    {
       Complex c1 = new Complex();
       System.out.println(c1.toString()); 
    }
}