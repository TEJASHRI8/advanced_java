package p1;
//import p1.Complex; //OK
class Program
{
    public static void main( String[] args )
    {
       Complex c1 = new Complex();
       System.out.println(c1.toString()); 
    }
}