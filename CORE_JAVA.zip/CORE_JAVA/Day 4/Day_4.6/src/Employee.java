package p2;
import p1.Person;
public class Employee extends Person
{
    @Override
    public String toString() 
    {
        return "Employee.toString()";
    }
}