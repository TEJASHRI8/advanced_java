import p2.Employee;
class Program
{
    public static void main( String[] args )
    {
       Employee emp = new Employee();
       System.out.println(emp.toString());
    }
}